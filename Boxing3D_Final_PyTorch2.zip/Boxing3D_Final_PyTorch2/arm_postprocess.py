import math
import numpy as np


def _clamp_segment_y_preserve_length(parent_pt, orig_vec, y_limit, fallback_dir_xz=(0.0, -1.0)):
    """
    단일 뼈대(parent -> child)에서 child의 Y(높이, 음수일수록 위)가 y_limit보다 높아지면
    Y를 y_limit으로 제한하되, 줄어든 수직 성분만큼 X와 Z 성분 길이를 비례 확대하여
    원래 3D 뼈대 길이 L = ||orig_vec|| 을 정확히 동일하게 유지합니다.
    """
    L = float(np.linalg.norm(orig_vec))
    if L < 1e-6:
        return (parent_pt + orig_vec).astype(np.float32), False

    candidate = parent_pt + orig_vec
    if candidate[1] >= y_limit:
        # MediaPipe/언리얼 좌표계에서 Y가 더 크거나 같으면 이미 제한 높이 이하 -> 수정 안 함
        return candidate.astype(np.float32), False

    # Y를 y_limit으로 내리되, 물리적 최대 길이 L을 넘지 않도록 안전 클립
    dy_new = float(np.clip(y_limit - parent_pt[1], -L, L))
    new_y = float(parent_pt[1]) + dy_new

    # 피타고라스 정리로 남은 수평(XZ) 반지름 계산: sqrt(L^2 - dy_new^2)
    r_new = math.sqrt(max(0.0, L * L - dy_new * dy_new))
    dx = float(orig_vec[0])
    dz = float(orig_vec[2])
    r_old = math.hypot(dx, dz)

    if r_old > 1e-6:
        scale = r_new / r_old
        dx_new = dx * scale
        dz_new = dz * scale
    else:
        fx, fz = fallback_dir_xz
        fn = math.hypot(fx, fz) + 1e-6
        dx_new = r_new * (fx / fn)
        dz_new = r_new * (fz / fn)

    new_child = np.array([parent_pt[0] + dx_new, new_y, parent_pt[2] + dz_new], dtype=np.float32)
    return new_child, True


def enforce_arm_y_limit_and_preserve_length(
    kps_3d,
    wrist_max_lift=0.06,
    elbow_max_lift=0.02,
    cap_at_head=True,
):
    """
    9개 관절(kps_3d: shape (9, 3))에 대해:
      - 관절 인덱스: 0:Nose, 2:R_Sh, 3:R_Elb, 4:R_Wri, 5:L_Sh, 6:L_Elb, 7:L_Wri
      - 좌표계: Y가 음수(-)일수록 위쪽(머리 방향)
    팔꿈치와 손목의 최대 높이(Y 하한값)를 제한하고,
    잘린 Y만큼 X·Z 방향으로 팔을 더 뻗어 상완/전완 뼈대 길이를 100% 보존합니다.

    Returns:
      out: 보정된 (9, 3) numpy array
      info: dict (양쪽 팔 클램핑 여부 및 보정 전/후 최대 뼈대 길이 오차)
    """
    if kps_3d is None:
        return None, {"clamped": False, "max_len_err_mm": 0.0}

    out = kps_3d.copy().astype(np.float32)
    nose_y = float(out[0, 1])

    clamped_any = False
    max_len_err = 0.0

    # (어깨, 팔꿈치, 손목, 기본 X 방향)
    arm_chains = [
        (2, 3, 4, (-0.2, -1.0)),  # 오른팔
        (5, 6, 7, (0.2, -1.0)),   # 왼팔
    ]

    for sh_idx, elb_idx, wri_idx, fallback_xz in arm_chains:
        sh = out[sh_idx].copy()
        elb_orig = out[elb_idx].copy()
        wri_orig = out[wri_idx].copy()

        v_upper = elb_orig - sh
        v_fore = wri_orig - elb_orig
        len_upper_orig = float(np.linalg.norm(v_upper))
        len_fore_orig = float(np.linalg.norm(v_fore))

        sh_y = float(sh[1])
        # 어깨 기준 허용 최대 상승 높이 (음수가 위쪽이므로 sh_y - lift)
        y_lim_elb = sh_y - elbow_max_lift
        y_lim_wri = sh_y - wrist_max_lift
        if cap_at_head:
            # 어떠한 경우에도 머리(Nose + 2cm 아래)보다 위로 뜨지 않게 보정
            head_cap = nose_y + 0.02
            y_lim_elb = max(y_lim_elb, head_cap)
            y_lim_wri = max(y_lim_wri, head_cap)

        # 1단계: 상완 (Shoulder -> Elbow) Y 제한 + XZ 길이 보존 연장
        elb_new, c1 = _clamp_segment_y_preserve_length(sh, v_upper, y_lim_elb, fallback_dir_xz=fallback_xz)

        # 2단계: 전완 (Elbow_new -> Wrist) Y 제한 + XZ 길이 보존 연장
        # 팔꿈치가 내려왔으면 기존 전완 방향/길이를 새 팔꿈치 기준으로 이어 붙인 뒤 손목 Y 제한 적용
        wri_new, c2 = _clamp_segment_y_preserve_length(elb_new, v_fore, y_lim_wri, fallback_dir_xz=fallback_xz)

        out[elb_idx] = elb_new
        out[wri_idx] = wri_new

        if c1 or c2:
            clamped_any = True

        len_upper_new = float(np.linalg.norm(out[elb_idx] - out[sh_idx]))
        len_fore_new = float(np.linalg.norm(out[wri_idx] - out[elb_idx]))
        max_len_err = max(max_len_err, abs(len_upper_new - len_upper_orig), abs(len_fore_new - len_fore_orig))

    return out, {
        "clamped": clamped_any,
        "max_len_err_mm": max_len_err * 1000.0,
    }


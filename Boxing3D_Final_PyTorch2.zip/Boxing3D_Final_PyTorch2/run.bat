@echo off
chcp 65001 > nul
cd /d "%~dp0"
set MPLCONFIGDIR=%TEMP%

echo =====================================================================
echo   Boxing 3D Final: MediaPipe + PyTorch2 + Y축 높이 제한 보정 실행
echo =====================================================================

if exist "%~dp0venv\Scripts\python.exe" (
    "%~dp0venv\Scripts\python.exe" "%~dp0run_boxing_3d.py" %*
    goto :end
)

where python > nul 2>&1
if not errorlevel 1 (
    python "%~dp0run_boxing_3d.py" %*
    goto :end
)

where py > nul 2>&1
if not errorlevel 1 (
    py "%~dp0run_boxing_3d.py" %*
    goto :end
)

echo [오류] 실행할 Python을 찾지 못했습니다.
echo 먼저 'install_requirements.bat'을 실행하거나 Python을 설치해 주세요.

:end
pause


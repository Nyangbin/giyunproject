import torch
import torch.nn as nn


class ResidualBlockV2(nn.Module):
    def __init__(self, hidden_dim, dropout=0.15):
        super().__init__()
        self.block = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.Dropout(dropout),
        )
        self.act = nn.GELU()

    def forward(self, x):
        return self.act(x + self.block(x))


class BoxingZOnlyRefiner(nn.Module):
    """
    PyTorch2 모델:
    MediaPipe의 2D(18차원) + 1차 3D(27차원) 총 45차원 입력을 받아
    X, Y 좌표는 원본 MediaPipe 값을 100% 그대로 고정 유지하고,
    오직 9개 관절의 Z축 보정값(delta_z, 9차원)만 예측하여 더하는 모델.
    """

    def __init__(self, hidden_dim=512, num_blocks=2, dropout=0.15):
        super().__init__()
        in_dim = 9 * 2 + 9 * 3  # 45차원 (2D XY + 3D XYZ)
        out_dim = 9             # 9차원 (오직 delta_z만 출력)

        self.input_layer = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )
        self.res_blocks = nn.ModuleList([
            ResidualBlockV2(hidden_dim, dropout=dropout) for _ in range(num_blocks)
        ])
        self.output_layer = nn.Linear(hidden_dim, out_dim)

        # 초기 출력이 0 근처에서 시작하도록 초기화 (초기 상태 = 원본 MediaPipe Z)
        nn.init.zeros_(self.output_layer.bias)
        nn.init.normal_(self.output_layer.weight, std=1e-3)

    def forward(self, mp_2d, mp_3d):
        B = mp_3d.shape[0]
        x = torch.cat([mp_2d.view(B, -1), mp_3d.view(B, -1)], dim=-1)  # (B, 45)
        h = self.input_layer(x)
        for blk in self.res_blocks:
            h = blk(h)

        delta_z = self.output_layer(h)  # (B, 9)

        # X, Y는 원본 MediaPipe 그대로 유지, Z축만 delta_z만큼 보정
        refined_3d = mp_3d.clone()
        refined_3d[:, :, 2] = mp_3d[:, :, 2] + delta_z
        refined_3d[:, 8, :] = 0.0  # Pelvis Root(8번 관절)는 원점 (0, 0, 0) 고정
        return refined_3d


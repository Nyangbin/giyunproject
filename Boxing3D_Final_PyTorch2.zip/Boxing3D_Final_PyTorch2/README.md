# Boxing 3D Final (MediaPipe + PyTorch2 + Y축 제한 보정)

이 폴더는 **MediaPipe Pose + PyTorch2 (`BoxingZOnlyRefiner`) + Y축 높이 제한 및 팔 길이 보존 XZ 연장 알고리즘**을 다른 PC로 그대로 복사·압축 전달해 바로 실행할 수 있도록 구성한 최종 배포 패키지입니다.

---

## 폴더 구성

* `run_boxing_3d.py`: 메인 실행 파일 (웹캠/샘플 3D 비교 뷰어 + 상단 버튼 UI)
* `refiner_model_v2.py`: `PyTorch2` (`BoxingZOnlyRefiner`, X·Y는 원본 MediaPipe 유지 / 9개 관절 `delta_z` 예측 모델)
* `arm_postprocess.py`: 주먹이 머리/어깨 위로 과도하게 뜨는 현상을 막고, Y를 제한한 만큼 X·Z 방향으로 팔 뼈대 길이를 100% 보존해 뻗어주는 파이썬 기하학 보정 알고리즘
* `checkpoints/boxing_depth_refiner_v2.pth`: 학습 완료된 `PyTorch2` 모델 가중치
* `samples/`: 웹캠 없이도 바로 시연·비교 가능한 언리얼 GT 샘플 6장 (`samples_gt.json` 포함)
* `requirements.txt`: 필요한 파이썬 라이브러리 목록
* `install_requirements.bat`: (Windows) 가상환경 생성 및 필수 라이브러리 원클릭 설치
* `run.bat`: (Windows) 원클릭 실행 파일

---

## 다른 사람 PC에서 실행하는 방법

### 방법 1) Windows 원클릭 실행 (가장 쉬움)
1. 이 폴더 전체를 압축(ZIP)해서 전달 후 압축을 풉니다. (PC에 Python 3.9~3.11이 설치되어 있어야 합니다.)
2. **`install_requirements.bat`** 을 더블클릭해 라이브러리를 설치합니다. (최초 1회)
3. **`run.bat`** 을 더블클릭하면 실행됩니다!

### 방법 2) 터미널(Mac / Linux / Windows 공통)
```bash
pip install -r requirements.txt
python run_boxing_3d.py
```

* 웹캠 없이 내장 정답 비교 샘플로만 실행하려면:
  ```bash
  python run_boxing_3d.py --sample
  ```
* GUI 없이 정상 작동 여부만 점검하려면:
  ```bash
  python run_boxing_3d.py --self-test
  ```

---

## 조작 방법 (상단 버튼 클릭 & 키보드 모두 지원)

상단 툴바 버튼을 마우스로 직접 클릭하거나 숫자키 **`1` ~ `8`** 을 누르면 한/영 키보드 상태와 무관하게 작동합니다.

* **`1` (또는 `y`) / `1:Y-Limit ON/OFF`**: Y축 높이 제한 + 팔 길이 보존 XZ 연장 알고리즘 ON/OFF
* **`2` / `3` (또는 `[` / `]`)**: 손목 최대 허용 높이 `2cm`씩 낮춤 / 높임 (기본: 어깨 위 `+2cm`)
* **`4` (`v`)**: 90도 측면 뷰 (깊이 Z 및 높이 비교 확인용)
* **`5` (`f`)**: 0도 정면 뷰
* **`6` (`r`)**: 기본 각도 초기화 (`Yaw 35°, Pitch 12°`)
* **`7` (`s`)**: 실시간 웹캠 ↔ 내장 샘플 모드 전환
* **`8` (`n`)**: 다음 샘플 보기
* **우측 3D 화면 마우스 드래그 / 휠**: 3D 공간 회전 및 줌 인/아웃
* **`c`**: 웹캠 장치 번호 전환 / **`q` 또는 `ESC`**: 종료


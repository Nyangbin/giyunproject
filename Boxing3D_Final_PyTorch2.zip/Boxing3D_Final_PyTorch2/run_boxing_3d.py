import os
import sys
import json
import math
import tempfile
import argparse

os.environ.setdefault("MPLCONFIGDIR", tempfile.gettempdir())


def _check_dependencies():
    missing = []
    for pkg, pip_name in [
        ("torch", "torch"),
        ("cv2", "opencv-python"),
        ("numpy", "numpy"),
        ("mediapipe", "mediapipe==0.10.14"),
    ]:
        try:
            __import__(pkg)
        except ImportError:
            missing.append(pip_name)
    if missing:
        print("=" * 64)
        print("[오류] 실행에 필요한 라이브러리가 설치되어 있지 않습니다.")
        print("먼저 아래 방법 중 하나를 실행해 주세요:")
        print("  1) 폴더 안의 'install_requirements.bat' 더블클릭 (Windows 권장)")
        print("  2) 터미널에서 직접 설치:")
        print(f"     pip install {' '.join(missing)}")
        print("=" * 64)
        sys.exit(1)


_check_dependencies()

import cv2
import torch
import numpy as np
import mediapipe as mp
from refiner_model_v2 import BoxingZOnlyRefiner
from arm_postprocess import enforce_arm_y_limit_and_preserve_length

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

JOINT_NAMES = [
    "Nose", "Neck", "R_Sh", "R_Elb", "R_Wri",
    "L_Sh", "L_Elb", "L_Wri", "Pelvis",
]

SKELETON_EDGES = [
    (8, 1), (1, 0),
    (1, 2), (2, 3), (3, 4),
    (1, 5), (5, 6), (6, 7),
]


class Synced3DViewer:
    """두 개의 3D 공간을 동일한 각도(Yaw, Pitch, Zoom)로 동기화 렌더링"""

    def __init__(self, pw=480, ph=480):
        self.pw = pw
        self.ph = ph
        self.yaw = 35.0
        self.pitch = 12.0
        self.distance = 2.6
        self.zoom = 1.15
        self.is_dragging = False
        self.last_x = 0
        self.last_y = 0
        self.buttons = []
        self.pending_action = None
        self.bar_h = 52

    def set_buttons(self, buttons):
        self.buttons = buttons

    def on_mouse(self, event, x, y, flags, param):
        if y < self.bar_h:
            if event == cv2.EVENT_LBUTTONDOWN:
                for (bx1, by1, bx2, by2, action, _) in self.buttons:
                    if bx1 <= x <= bx2 and by1 <= y <= by2:
                        self.pending_action = action
                        return
            return
        if x < self.pw:
            return
        if event == cv2.EVENT_LBUTTONDOWN:
            self.is_dragging = True
            self.last_x = x
            self.last_y = y
        elif event == cv2.EVENT_MOUSEMOVE and self.is_dragging:
            dx = x - self.last_x
            dy = y - self.last_y
            self.yaw += dx * 0.5
            self.pitch = max(-85.0, min(85.0, self.pitch + dy * 0.5))
            self.last_x = x
            self.last_y = y
        elif event == cv2.EVENT_LBUTTONUP:
            self.is_dragging = False
        elif event == cv2.EVENT_MOUSEWHEEL:
            if flags > 0:
                self.zoom = min(2.5, self.zoom * 1.1)
            else:
                self.zoom = max(0.4, self.zoom * 0.9)

    def reset_view(self):
        self.yaw = 35.0
        self.pitch = 12.0
        self.zoom = 1.15

    def set_front_view(self):
        self.yaw = 0.0
        self.pitch = 0.0
        self.zoom = 1.15

    def set_side_view(self):
        self.yaw = 90.0
        self.pitch = 0.0
        self.zoom = 1.15

    def project(self, pt_3d):
        x, y, z = pt_3d
        ry = math.radians(self.yaw)
        cy, sy = math.cos(ry), math.sin(ry)
        x1 = x * cy + z * sy
        y1 = y
        z1 = -x * sy + z * cy

        rp = math.radians(self.pitch)
        cp, sp = math.cos(rp), math.sin(rp)
        x2 = x1
        y2 = y1 * cp - z1 * sp
        z2 = y1 * sp + z1 * cp

        cam_z = max(0.2, z2 + self.distance)
        fov = (self.ph * 0.9 * self.zoom) / cam_z
        u = int(self.pw / 2 + x2 * fov)
        v = int(self.ph / 2 + y2 * fov)
        return u, v, cam_z

    def render_panel(self, kps_3d, title, subtitle, bone_col, joint_col, gt_3d=None):
        canvas = np.full((self.ph, self.pw, 3), 22, dtype=np.uint8)

        gy = 0.45
        for gx in np.arange(-0.8, 0.81, 0.2):
            u1, v1, _ = self.project([gx, gy, -0.8])
            u2, v2, _ = self.project([gx, gy, 0.8])
            cv2.line(canvas, (u1, v1), (u2, v2), (40, 44, 52), 1, cv2.LINE_AA)
        for gz in np.arange(-0.8, 0.81, 0.2):
            u1, v1, _ = self.project([-0.8, gy, gz])
            u2, v2, _ = self.project([0.8, gy, gz])
            cv2.line(canvas, (u1, v1), (u2, v2), (40, 44, 52), 1, cv2.LINE_AA)

        u0, v0, _ = self.project([0, 0, 0])
        for end_pt, col, lbl in [
            ([0.25, 0, 0], (0, 0, 255), "X"),
            ([0, -0.25, 0], (0, 255, 0), "Y"),
            ([0, 0, -0.25], (255, 140, 0), "Z(Front)"),
        ]:
            ue, ve, _ = self.project(end_pt)
            cv2.arrowedLine(canvas, (u0, v0), (ue, ve), col, 2, tipLength=0.18)
            cv2.putText(canvas, lbl, (ue + 4, ve + 4), cv2.FONT_HERSHEY_SIMPLEX, 0.36, col, 1, cv2.LINE_AA)

        if gt_3d is not None:
            gt_pts = [self.project(pt) for pt in gt_3d]
            for j1, j2 in SKELETON_EDGES:
                cv2.line(canvas, (gt_pts[j1][0], gt_pts[j1][1]), (gt_pts[j2][0], gt_pts[j2][1]),
                         (110, 110, 110), 1, cv2.LINE_AA)
            for u, v, _ in gt_pts:
                cv2.circle(canvas, (u, v), 3, (150, 150, 150), -1)

        if kps_3d is not None:
            proj_pts = []
            for i, pt in enumerate(kps_3d):
                u, v, zc = self.project(pt)
                proj_pts.append((u, v, zc, i))

            for j1, j2 in SKELETON_EDGES:
                u1, v1, _, _ = proj_pts[j1]
                u2, v2, _, _ = proj_pts[j2]
                cv2.line(canvas, (u1, v1), (u2, v2), bone_col, 3, cv2.LINE_AA)

            proj_pts.sort(key=lambda x: x[2], reverse=True)
            for u, v, zc, idx in proj_pts:
                rad = max(4, min(14, int(7 * (2.2 / zc))))
                pt_col = (0, 255, 0) if idx == 8 else joint_col
                cv2.circle(canvas, (u, v), rad, pt_col, -1, cv2.LINE_AA)
                cv2.circle(canvas, (u, v), rad + 1, (255, 255, 255), 1, cv2.LINE_AA)
                if idx in [4, 7]:
                    z_val = kps_3d[idx][2]
                    cv2.putText(canvas, f"{JOINT_NAMES[idx]} Z:{z_val:+.2f}m", (u + 7, v - 4),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.36, (235, 235, 235), 1, cv2.LINE_AA)

        cv2.putText(canvas, title, (12, 26), cv2.FONT_HERSHEY_SIMPLEX, 0.50, bone_col, 2, cv2.LINE_AA)
        cv2.putText(canvas, subtitle, (12, 48), cv2.FONT_HERSHEY_SIMPLEX, 0.37, (190, 190, 190), 1, cv2.LINE_AA)
        cv2.putText(canvas, f"Yaw:{int(self.yaw)} Pitch:{int(self.pitch)} Zoom:{self.zoom:.1f}x",
                    (12, self.ph - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.38, (140, 140, 140), 1, cv2.LINE_AA)
        return canvas


def extract_features(res, w, h):
    if not (res.pose_landmarks and res.pose_world_landmarks):
        return None, None, None

    lm2 = res.pose_landmarks.landmark
    lm3 = res.pose_world_landmarks.landmark

    def g2(i):
        return np.array([lm2[i].x, lm2[i].y], dtype=np.float32)

    def g3(i):
        return np.array([lm3[i].x, lm3[i].y, lm3[i].z], dtype=np.float32)

    px_nose = (int(lm2[0].x * w), int(lm2[0].y * h))
    px_lsh = (int(lm2[11].x * w), int(lm2[11].y * h))
    px_rsh = (int(lm2[12].x * w), int(lm2[12].y * h))
    px_neck = ((px_lsh[0] + px_rsh[0]) // 2, (px_lsh[1] + px_rsh[1]) // 2)
    px_lel = (int(lm2[13].x * w), int(lm2[13].y * h))
    px_rel = (int(lm2[14].x * w), int(lm2[14].y * h))
    px_lwr = (int(lm2[15].x * w), int(lm2[15].y * h))
    px_rwr = (int(lm2[16].x * w), int(lm2[16].y * h))
    px_lhip = (int(lm2[23].x * w), int(lm2[23].y * h))
    px_rhip = (int(lm2[24].x * w), int(lm2[24].y * h))
    px_pelvis = ((px_lhip[0] + px_rhip[0]) // 2, (px_lhip[1] + px_rhip[1]) // 2)
    px_2d = [px_nose, px_neck, px_rsh, px_rel, px_rwr, px_lsh, px_lel, px_lwr, px_pelvis]

    pelvis_2d = (g2(23) + g2(24)) / 2.0
    neck_2d = (g2(11) + g2(12)) / 2.0
    spine_2d = np.linalg.norm(neck_2d - pelvis_2d) + 1e-6

    norm_2d = np.array([
        (g2(0) - pelvis_2d) / spine_2d,
        (neck_2d - pelvis_2d) / spine_2d,
        (g2(12) - pelvis_2d) / spine_2d,
        (g2(14) - pelvis_2d) / spine_2d,
        (g2(16) - pelvis_2d) / spine_2d,
        (g2(11) - pelvis_2d) / spine_2d,
        (g2(13) - pelvis_2d) / spine_2d,
        (g2(15) - pelvis_2d) / spine_2d,
        [0.0, 0.0],
    ], dtype=np.float32)

    pelvis_3d = (g3(23) + g3(24)) / 2.0
    neck_3d = (g3(11) + g3(12)) / 2.0
    mp_3d = np.array([
        g3(0) - pelvis_3d,
        neck_3d - pelvis_3d,
        g3(12) - pelvis_3d,
        g3(14) - pelvis_3d,
        g3(16) - pelvis_3d,
        g3(11) - pelvis_3d,
        g3(13) - pelvis_3d,
        g3(15) - pelvis_3d,
        [0.0, 0.0, 0.0],
    ], dtype=np.float32)

    return px_2d, norm_2d, mp_3d


def open_camera(cam_index):
    if os.name == "nt":
        cap = cv2.VideoCapture(cam_index, cv2.CAP_DSHOW)
        if cap.isOpened():
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            return cap
        cap.release()
    cap = cv2.VideoCapture(cam_index)
    if cap.isOpened():
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    return cap


def load_model(device):
    ckpt_path = os.path.join(BASE_DIR, "checkpoints", "boxing_depth_refiner_v2.pth")
    if not os.path.exists(ckpt_path):
        raise FileNotFoundError(f"체크포인트 파일이 없습니다: {ckpt_path}")
    ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
    cfg = ckpt["config"]
    model = BoxingZOnlyRefiner(
        hidden_dim=cfg["hidden_dim"],
        num_blocks=cfg["num_blocks"],
        dropout=cfg["dropout"],
    ).to(device)
    model.load_state_dict(ckpt["model_state"])
    model.eval()
    return model, cfg


def load_samples():
    samples_json = os.path.join(BASE_DIR, "samples", "samples_gt.json")
    if not os.path.exists(samples_json):
        return []
    with open(samples_json, "r", encoding="utf-8") as f:
        return json.load(f)


def run_self_test():
    """GUI/웹캠 없이 배포 패키지 정상 작동 검증"""
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    refiner, cfg = load_model(device)
    sample_items = load_samples()

    mp_pose = mp.solutions.pose
    pose = mp_pose.Pose(static_image_mode=True, model_complexity=1, min_detection_confidence=0.5)

    print(f"[Self-Test] Device: {device}")
    print(f"[Self-Test] PyTorch2 Config: epochs={cfg.get('epochs')}, lr={cfg.get('lr')}, axis_weights={cfg.get('axis_weights')}")
    print(f"[Self-Test] Samples Found: {len(sample_items)}")

    for item in sample_items:
        img_path = os.path.join(BASE_DIR, "samples", item["image_path"])
        img = cv2.imread(img_path)
        rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        res = pose.process(rgb)
        _, norm_2d, mp_3d = extract_features(res, rgb.shape[1], rgb.shape[0])
        if mp_3d is not None:
            t2d = torch.from_numpy(norm_2d).unsqueeze(0).to(device)
            t3d = torch.from_numpy(mp_3d).unsqueeze(0).to(device)
            with torch.no_grad():
                p2 = refiner(t2d, t3d)[0].cpu().numpy()
            post, info = enforce_arm_y_limit_and_preserve_length(p2, wrist_max_lift=0.02, elbow_max_lift=0.00)
            gt = np.array(item["keypoints_3d"], dtype=np.float32)
            err_a = np.abs(mp_3d[:, 2] - gt[:, 2]).mean() * 1000.0
            err_b = np.abs(post[:, 2] - gt[:, 2]).mean() * 1000.0
            print(f"  - {item['image_path']}: Raw Z-Err={err_a:.1f}mm -> PyTorch2+YLim Z-Err={err_b:.1f}mm (LenErr={info['max_len_err_mm']:.5f}mm)")

    pose.close()
    print("[Self-Test] PASSED! 배포 패키지 정상 동작 확인 완료.")


def main():
    parser = argparse.ArgumentParser(description="Boxing 3D Final (PyTorch2 + Y-Limit Arm Algorithm)")
    parser.add_argument("--sample", action="store_true", help="내장 언리얼 GT 샘플 비교 모드로 시작")
    parser.add_argument("--self-test", action="store_true", help="GUI 없이 패키지 정상 작동 자가 검증")
    args = parser.parse_args()

    if args.self_test:
        run_self_test()
        return

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    refiner, cfg = load_model(device)
    print(f"PyTorch2 + Y-Limit 최종 버전 로드 완료! (Device={device}, axis_weights={cfg['axis_weights']})")

    mp_pose = mp.solutions.pose
    pose = mp_pose.Pose(
        static_image_mode=False,
        model_complexity=1,
        smooth_landmarks=True,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5,
    )

    sample_items = load_samples()
    sample_idx = 0

    cam_index = 0
    cap = None
    use_sample_mode = args.sample
    if not use_sample_mode:
        cap = open_camera(cam_index)
        if not cap.isOpened():
            cam_index = 1
            cap = open_camera(cam_index)
        if not cap.isOpened():
            print("[안내] 연결된 웹캠이 없어 '언리얼 GT 샘플 비교 모드'로 자동 시작합니다.")
            use_sample_mode = True

    use_y_limit = True
    wrist_max_lift = 0.02   # 손목: 어깨 위로 최대 +2cm
    elbow_max_lift = 0.00   # 팔꿈치: 어깨 높이 이하

    pw, ph = 480, 480
    bar_h = 52
    viewer = Synced3DViewer(pw=pw, ph=ph)
    viewer.bar_h = bar_h

    ui_buttons = [
        (10,   10, 175, 42, "toggle_y", "1:Y-Limit ON/OFF"),
        (185,  10, 325, 42, "lower_y",  "2:Limit -2cm"),
        (335,  10, 475, 42, "raise_y",  "3:Limit +2cm"),
        (495,  10, 625, 42, "side",     "4:Side(90)"),
        (635,  10, 765, 42, "front",    "5:Front(0)"),
        (775,  10, 895, 42, "reset",    "6:Reset"),
        (915,  10, 1055, 42, "sample",  "7:Sample"),
        (1065, 10, 1185, 42, "next",    "8:Next"),
    ]
    viewer.set_buttons(ui_buttons)
    win_name = "Boxing 3D Final [PyTorch2 + Y-Limit]: Input | Raw MediaPipe (A) | PyTorch2 + Y-Limit (B)"
    cv2.namedWindow(win_name, cv2.WINDOW_AUTOSIZE)
    cv2.setMouseCallback(win_name, viewer.on_mouse)

    print("\n[조작 방법 - 숫자키/상단 버튼 클릭은 한글 입력 상태에서도 동작합니다]")
    print("  - [1] / 'y' / 버튼 클릭 : Y축 제한 + 팔길이 보존 XZ 연장 ON / OFF")
    print("  - [2] / [3] / '[' / ']' : 손목 최대 높이 한계 낮춤 / 높임 (2cm 단위)")
    print("  - [4] / 'v': 90도 측면 뷰  |  [5] / 'f': 0도 정면 뷰  |  [6] / 'r': 기본 뷰")
    print("  - [7] / 's': 웹캠 <-> 샘플 전환  |  [8] / 'n': 다음 샘플  |  'c': 웹캠 전환  |  'q'/ESC: 종료\n")

    fps_count, fps_text = 0, "FPS: 0"
    last_t = cv2.getTickCount()

    while True:
        gt_3d = None
        if not use_sample_mode:
            if cap is None or not cap.isOpened():
                cap = open_camera(cam_index)
            ret, raw = cap.read() if cap is not None else (False, None)
            if not ret:
                cv2.waitKey(30)
                continue
            frame = cv2.resize(raw, (pw, ph))
            src_label = f"WebCam Live (Cam {cam_index})"
        else:
            if len(sample_items) > 0:
                item = sample_items[sample_idx]
                img_path = os.path.join(BASE_DIR, "samples", item["image_path"])
                frame = cv2.resize(cv2.imread(img_path), (pw, ph))
                gt_3d = np.array(item["keypoints_3d"], dtype=np.float32)
                src_label = f"Sample [{item['image_path']}] (Gray=GT)"
            else:
                frame = np.zeros((ph, pw, 3), dtype=np.uint8)
                src_label = "No Samples"

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        res = pose.process(rgb)
        px_2d, norm_2d, mp_3d = extract_features(res, pw, ph)

        refined_3d = None
        raw_p2_3d = None
        algo_info = {"clamped": False, "max_len_err_mm": 0.0}
        if mp_3d is not None:
            t2d = torch.from_numpy(norm_2d).unsqueeze(0).to(device)
            t3d = torch.from_numpy(mp_3d).unsqueeze(0).to(device)
            with torch.no_grad():
                raw_p2_3d = refiner(t2d, t3d)[0].cpu().numpy()
            refined_3d = raw_p2_3d.copy()

            if use_y_limit:
                refined_3d, algo_info = enforce_arm_y_limit_and_preserve_length(
                    refined_3d,
                    wrist_max_lift=wrist_max_lift,
                    elbow_max_lift=elbow_max_lift,
                    cap_at_head=True,
                )

            for j1, j2 in SKELETON_EDGES:
                cv2.line(frame, px_2d[j1], px_2d[j2], (0, 255, 0), 2, cv2.LINE_AA)
            for i, (px, py) in enumerate(px_2d):
                col = (0, 0, 255) if i in [4, 7] else (0, 220, 255)
                cv2.circle(frame, (px, py), 5, col, -1, cv2.LINE_AA)

        cv2.putText(frame, f"{src_label} | {fps_text}", (12, 24),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.46, (255, 255, 255), 2, cv2.LINE_AA)
        algo_state = f"ON (Wri<=Sh{wrist_max_lift*100:+.0f}cm)" if use_y_limit else "OFF"
        clamp_tag = " [CLAMPED->XZ Ext]" if algo_info["clamped"] else ""
        cv2.putText(frame, f"Y-Limit Algo: {algo_state}{clamp_tag}",
                    (12, 46), cv2.FONT_HERSHEY_SIMPLEX, 0.40, (0, 255, 180) if use_y_limit else (140, 140, 255), 1, cv2.LINE_AA)
        if mp_3d is not None and refined_3d is not None and raw_p2_3d is not None:
            cv2.putText(frame, f"WriY(up=-): R {raw_p2_3d[4][1]:+.2f}->{refined_3d[4][1]:+.2f} | L {raw_p2_3d[7][1]:+.2f}->{refined_3d[7][1]:+.2f}",
                        (12, 66), cv2.FONT_HERSHEY_SIMPLEX, 0.37, (0, 255, 255), 1, cv2.LINE_AA)
            cv2.putText(frame, f"ShY:{refined_3d[2][1]:+.2f} NoseY:{refined_3d[0][1]:+.2f} | WriZ R:{refined_3d[4][2]:+.2f} L:{refined_3d[7][2]:+.2f} | LenErr:{algo_info['max_len_err_mm']:.3f}mm",
                        (12, 84), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 220, 255), 1, cv2.LINE_AA)

        sub_a = "Untouched MediaPipe 3D"
        sub_b = f"PyTorch2 + Y-Limit:{'ON' if use_y_limit else 'OFF'} (Wri<=Sh{wrist_max_lift*100:+.0f}cm)"
        if gt_3d is not None and mp_3d is not None and refined_3d is not None:
            z_err_a = np.abs(mp_3d[:, 2] - gt_3d[:, 2]).mean() * 1000.0
            z_err_b = np.abs(refined_3d[:, 2] - gt_3d[:, 2]).mean() * 1000.0
            sub_a = f"Z-Err vs GT: {z_err_a:.1f} mm"
            sub_b = f"Z-Err vs GT: {z_err_b:.1f} mm | Y-Lim:{'ON' if use_y_limit else 'OFF'}"

        panel_a = viewer.render_panel(mp_3d, "Model A: Raw MediaPipe", sub_a,
                                      bone_col=(255, 170, 50), joint_col=(255, 230, 0), gt_3d=gt_3d)
        panel_b = viewer.render_panel(refined_3d, "Model B: PyTorch2 + Y-Limit", sub_b,
                                      bone_col=(0, 255, 120), joint_col=(0, 200, 255), gt_3d=gt_3d)

        cv2.line(panel_a, (0, 0), (0, ph), (90, 90, 90), 2)
        cv2.line(panel_b, (0, 0), (0, ph), (90, 90, 90), 2)
        body_row = np.hstack((frame, panel_a, panel_b))

        topbar = np.full((bar_h, pw * 3, 3), 30, dtype=np.uint8)
        for (bx1, by1, bx2, by2, action, lbl) in ui_buttons:
            active_bg = (45, 120, 70) if (action == "toggle_y" and use_y_limit) else (58, 60, 72)
            cv2.rectangle(topbar, (bx1, by1), (bx2, by2), active_bg, -1)
            cv2.rectangle(topbar, (bx1, by1), (bx2, by2), (145, 145, 160), 1)
            cv2.putText(topbar, lbl, (bx1 + 8, by2 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.43, (245, 245, 245), 1, cv2.LINE_AA)
        cv2.putText(topbar, f"Wri<=Sh{wrist_max_lift*100:+.0f}cm | q:Quit",
                    (1200, 32), cv2.FONT_HERSHEY_SIMPLEX, 0.46, (0, 230, 255), 1, cv2.LINE_AA)
        cv2.line(topbar, (0, bar_h - 1), (pw * 3, bar_h - 1), (95, 95, 95), 1)
        combined = np.vstack((topbar, body_row))

        fps_count += 1
        ct = cv2.getTickCount()
        dt = (ct - last_t) / cv2.getTickFrequency()
        if dt >= 1.0:
            fps_text = f"FPS: {int(fps_count / dt)}"
            fps_count = 0
            last_t = ct

        cv2.imshow(win_name, combined)
        raw_key = cv2.waitKeyEx(1)
        key = raw_key & 0xFF if raw_key != -1 else -1

        action = viewer.pending_action
        viewer.pending_action = None

        if action == "toggle_y" or key in (ord('1'), ord('y'), ord('Y')):
            use_y_limit = not use_y_limit
            print(f"[설정 변경] Y축 제한 알고리즘: {'ON' if use_y_limit else 'OFF'}")
        elif action == "lower_y" or key in (ord('2'), ord('['), ord('{'), ord('-'), ord('_')) or raw_key in (2621440, 65364):
            wrist_max_lift = max(-0.10, round(wrist_max_lift - 0.02, 2))
            elbow_max_lift = max(-0.10, round(elbow_max_lift - 0.02, 2))
            print(f"[설정 변경] 손목 최대 높이 한계: Sh{wrist_max_lift*100:+.0f}cm")
        elif action == "raise_y" or key in (ord('3'), ord(']'), ord('}'), ord('='), ord('+')) or raw_key in (2490368, 65362):
            wrist_max_lift = min(0.25, round(wrist_max_lift + 0.02, 2))
            elbow_max_lift = min(0.20, round(elbow_max_lift + 0.02, 2))
            print(f"[설정 변경] 손목 최대 높이 한계: Sh{wrist_max_lift*100:+.0f}cm")
        elif action == "side" or key in (ord('4'), ord('v'), ord('V')):
            viewer.set_side_view()
        elif action == "front" or key in (ord('5'), ord('f'), ord('F')):
            viewer.set_front_view()
        elif action == "reset" or key in (ord('6'), ord('r'), ord('R')):
            viewer.reset_view()
        elif action == "sample" or key in (ord('7'), ord('s'), ord('S')):
            use_sample_mode = not use_sample_mode
            print(f"[모드 전환] {'샘플 모드' if use_sample_mode else '실시간 웹캠 모드'}")
        elif (action == "next" or key in (ord('8'), ord('n'), ord('N'))) and len(sample_items) > 0:
            use_sample_mode = True
            sample_idx = (sample_idx + 1) % len(sample_items)
        elif key in (ord('c'), ord('C')) and not use_sample_mode:
            cam_index = (cam_index + 1) % 3
            if cap is not None:
                cap.release()
            cap = open_camera(cam_index)
        elif key in (ord('q'), ord('Q'), 27):
            break

    pose.close()
    if cap is not None:
        cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()


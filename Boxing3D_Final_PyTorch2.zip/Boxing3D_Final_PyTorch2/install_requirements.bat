@echo off
chcp 65001 > nul
cd /d "%~dp0"
echo =====================================================================
echo   Boxing 3D Final (PyTorch2 + Y축 제한 보정) 초기 환경 설치
echo =====================================================================

where python > nul 2>&1
if errorlevel 1 (
    echo [오류] Python이 설치되어 있지 않습니다.
    echo Python 3.9 ~ 3.11을 먼저 설치한 뒤 다시 실행해 주세요.
    pause
    exit /b 1
)

if not exist "venv\Scripts\python.exe" (
    echo [1/2] 독립 가상환경(venv) 생성 중...
    python -m venv venv
)

echo [2/2] 필수 라이브러리 설치 중 (torch, opencv-python, mediapipe, numpy)...
"venv\Scripts\python.exe" -m pip install --upgrade pip
"venv\Scripts\python.exe" -m pip install -r requirements.txt

echo.
echo 설치가 완료되었습니다! 이제 'run.bat'을 더블클릭해 실행하세요.
pause

